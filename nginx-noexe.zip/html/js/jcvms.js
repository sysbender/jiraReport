/**
 * Created by jmeng on 3/21/2017.
 */


var VmQuery = function () {
    var self = this;
    // data for filter
    self.selectedFilter = ko.observable();
    self.availableFilters = ko.observableArray([]);
    // queries
    self.queries = ko.observableArray();
    /*----------data table-------------------------------------------------------------------------------*/
    self.dataTable = ko.observable(new google.visualization.DataTable());

    self.dataTableCsvUri = ko.computed(function () {
        var csv = google.visualization.dataTableToCsv(self.dataTable());
        return 'data:application/csv;charset=utf-8,' + encodeURIComponent(csv);
    }, this);



    // method for fitler
    self.addFilter = function (filter) {
        self.availableFilters.push(filter);
        window.console.log(self.availableFilters);
    }
    self.removeFilter = function () {
        self.availableFilters.pop();
        window.console.log(self.availableFilters);
    }
    self.clearFilter = function () {
        for (var i = 0; i < self.availableFilters.length; i++) {
            self.availableFilters.pop();
        }
        window.console.log(self.availableFilters);
    }
    self.testAddFilter = function () {
        self.availableFilters.push(new Filter('1', 'myfilter', 'project=sp', 'http-jira'));
        console.log(self.availableFilters);
    }

    /*----------query-------------------------------------------------------------------------------*/

    // methods
    self.addQuery = function () {   // ?? where get this filter
        self.queries.push(new Query(self.selectedFilter().name, self.selectedFilter()));
        window.console.log(self.selectedFilter().name);
    };
    self.removeQuery = function (query) {
        self.queries.remove(query);
    };
    self.retrieveAllWorklogs = function () {
        console.log(" === retrieve all worklogs =" + self.queries().length);
        for (var i = 0; i < self.queries().length; i++) {
            console.log(self.queries()[i]);

            (self.queries()[i]).retrieveWorklogs();
        }
    };

    self.worklogToTableData = function () {
        var data = [];
        // for each query
        for (var i = 0; i < self.queries().length; i++) {
            data.push();
            // for each worklog array
            for (var j = 0; j < self.queries()[i].worklogs.length; j++) {
                // add label attribute to worklog obj
                var currentWorklog = self.queries()[i].worklogs[j];
                currentWorklog['label'] = self.queries()[i].label;
                data.push(currentWorklog);
            }
        }
        return data;
    };

    // draw table for queries
    self.drawOriginalDataTable = function () {
        window.console.log("start draw original table");
        self.dataTable(dataToDataTable(self.worklogToTableData()));
        drawTable(self.worklogToTableData(), 'div_originalDataTable');

    };


};

var VmTransform = function () {
    var self = this;
    //public
    self.transforms;
    self.transformedDataTable;
};

var VmChart = function () {
    var self = this;
    // public
    self.chartOptions;
    self.saveDefinition;
    self.loadDefinition;
    self.loadedDefinition;
};

var vmMaster = (function () {
    var self = this;
    self.vmQuery = new VmQuery();
    self.vmTransform = new VmTransform();
    self.vmChart = new VmChart();
})();

