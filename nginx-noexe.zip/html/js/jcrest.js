/**
 * Created by jmeng on 3/6/2017.
 */

// rest retrieve - put data into an array
function restRetrieveStartAt(restUrl, jsonCallback, startAt, maxResults, arrayData) {
    if(startAt ==0) {
        $('#ajax-process-bar').progressbar({ value: 5 });
    }
    var url = restUrl + '&startAt=' + startAt + '&maxResults=' + maxResults;

    // global variable : jirarest_proxy server side perl for proxy
    var urlPrefix = (typeof jirarest_proxy === 'undefined') ? 'jcrest.pl/getjira?url=' : jirarest_proxy;
    // encode url add prefix
    var newRestUrl = urlPrefix + encodeURIComponent(url);
    // add suffix for pagination

    console.log('==============newRestUrl = ' + newRestUrl);
    $.ajax({
        url: newRestUrl,
        type: "GET",
        dataType: 'json',
        contentType: 'application/json',
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            var nStartAt = parseInt(data.startAt);
            var nMaxResults = parseInt(data.maxResults);
            var nTotal = parseInt(data.total);
            var nNewStartAt = nStartAt + nMaxResults;


            if (( nNewStartAt) < nTotal) {
                var prog = Math.round((100 * nNewStartAt)/nTotal);
                console.log('================== start recursively : new start= ' + nNewStartAt + ' total = ' + nTotal + 'prog=' + prog);
                $('#ajax-process-bar').progressbar({ value: prog });

                restRetrieveStartAt(restUrl, jsonCallback, nNewStartAt, nMaxResults, arrayData);
            }
            jsonCallback(data, restUrl, arrayData, nNewStartAt);


        },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
            console.log('error =========');
        },
        progress: function(e) {

            if(e.lengthComputable) {
                var pct = (e.loaded / e.total) * 100;

                $('#ajax-process-bar')
                    .progressbar('option', 'value', pct)
                    .children('.ui-progressbar-value')
                    .html(pct.toPrecision(3) + '%')
                    .css('display', 'block');
            } else {
                console.warn('Content Length not reported!');
            }
        }

    });
}






// call rest api recursively and get all records of worklogs
function restGetStartAt(restUrl, jsonCallback, startAt, maxResults) {
    if(startAt ==0) {
        $('#ajax-process-bar').progressbar({ value: 5 });
    }
    var url = restUrl + '&startAt=' + startAt + '&maxResults=' + maxResults;

    // global variable : jirarest_proxy server side perl for proxy
    var urlPrefix = (typeof jirarest_proxy === 'undefined') ? 'jcrest.pl/getjira?url=' : jirarest_proxy;
    // encode url add prefix
    var newRestUrl = urlPrefix + encodeURIComponent(url);
    // add suffix for pagination

    console.log('==============newRestUrl = ' + newRestUrl);
    $.ajax({
        url: newRestUrl,
        type: "GET",
        dataType: 'json',
        contentType: 'application/json',
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            var nStartAt = parseInt(data.startAt);
            var nMaxResults = parseInt(data.maxResults);
            var nTotal = parseInt(data.total);
            var nNewStartAt = nStartAt + nMaxResults;


            if (( nNewStartAt) < nTotal) {
                var prog = Math.round((100 * nNewStartAt)/nTotal);
                console.log('================== start recursively : new start= ' + nNewStartAt + ' total = ' + nTotal + 'prog=' + prog);
                $('#ajax-process-bar').progressbar({ value: prog });

                restGetStartAt(restUrl, jsonCallback, nNewStartAt, nMaxResults);
            }
            jsonCallback(data, restUrl);


        },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
            console.log('error =========');
        },
        progress: function(e) {

            if(e.lengthComputable) {
                var pct = (e.loaded / e.total) * 100;

                $('#ajax-process-bar')
                    .progressbar('option', 'value', pct)
                    .children('.ui-progressbar-value')
                    .html(pct.toPrecision(3) + '%')
                    .css('display', 'block');
            } else {
                console.warn('Content Length not reported!');
            }
        }

    });
}




//   jira rest api: http://jira.presagis.com/rest/api/2/filter/favourite
// get json data from restUrl, then use jsonCallback to process the data
function restGet(restUrl, jsonCallback ) {
    $('#ajax-process-bar').progressbar({ value: 5});

    // global variable : jirarest_proxy server side perl for proxy
    var urlPrefix = (typeof jirarest_proxy === 'undefined') ? 'jcrest.pl/getjira?url=' : jirarest_proxy;
    var url = (urlPrefix ==="")? restUrl : encodeURIComponent(restUrl);
    var newRestUrl = urlPrefix +  url;
    console.log("*********** restGet");
    console.log("restUrl = " + restUrl);
    console.log("urlprefix = " + urlPrefix);
    console.log("newRestUrl = " + newRestUrl);
    $.ajax({
        url: newRestUrl,
        type: "GET",
        dataType: 'json',
        contentType: 'application/json',
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            jsonCallback(data, restUrl);
        },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
            alert("fail to get : " + restUrl);
        },
        progress: function(e) {

            if(e.lengthComputable) {
                var pct = (e.loaded / e.total) * 100;

                $('#ajax-process-bar')
                    .progressbar('option', 'value', pct)
                    .children('.ui-progressbar-value')
                    .html(pct.toPrecision(3) + '%')
                    .css('display', 'block');
            } else {
                console.warn('Content Length not reported!');
            }
        }
    });
}


