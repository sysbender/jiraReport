/**
 * Created by jason on 3/12/2017.
 */
// class to represent a search defined by a filter

