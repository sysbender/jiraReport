/**
 * Created by jmeng on 3/7/2017.
 */


// array for all worklogs
var worklogArray = [];

// url for login - support delete(logout)/get(login status)/post(login)
var jirarest_login = '/jcrest.pl/login';
// jirarest_proxy - as a prefix to real rest url
var jirarest_proxy = 'jcrest.pl/getjira?url=';
// real rest api
var jirarest_api = 'http://jira.presagis.com/rest/api/2';
var jirarest_suffix = '&fields=worklog,project,issuetype';
var jirarest_maxResults = 100;  // how many issues for each query
// set for ajax promise
var promiseSet = new Set();


// fill select choices
$(document).ready(function () {
    console.log('ready  ddd');



    // restGet('http://jira.presagis.com/rest/api/2/filter/favourite', fillFilterSelect);
    $('#ajax-process-bar').height(5);
    $('#ajax-process-bar').progressbar({value: 0});
    // check login
    checkLoginStatus();


//loadFilters();
    var jcViewModel = new JCViewModel();
    jcViewModel.initTransformerFields();

//jcViewModel.loadFilters();
    ko.applyBindings(jcViewModel);



});

// worklog fields definition

//description worklog data fields
var dataFields = [
    {name: 'projectKey', type: 'string', header:'projectKey'},
    {name: 'issueType', type: 'string', header:'issueType'},
    {name: 'updateAuthorName', type: 'string', header:'updateAuthorName'},
    {name: 'created', type: 'date', header:'created'},
    {name: 'updated', type: 'date', header:'updated'},
    {name: 'started', type: 'date', header:'started'},
    {name: 'timeSpentSeconds', type: 'number', header:'timeSpentSeconds'},
    {name: 'label', type: 'string' , header:'label'}
];


function getFieldType(fieldName) {
    for(var i=0; i<dataFields.length; i++){
        if (dataFields[i].name == fieldName){
            return dataFields[i].type;
        }
    }
    return "string";
}

function getFieldHeader(fieldName){
    for(var i=0; i<dataFields.length; i++){
        if (dataFields[i].name == fieldName){
            return dataFields[i].header;
        }
    }
    return "noheader";
}


// check login status
function checkLoginStatus() {

    $.ajax({
        url: '/jcrest.pl/login',
        type: 'get',
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            showLoginOnNavbar(false);  // loggedin=true, show=false
            console.log('check login status = true');

        },
        error: function (jqXhr, textStatus, errorThrown) {
            showLoginOnNavbar(true);   // loggedin=false, show=true
            console.log('check login status = false');
        }
    });

}
//
function showLoginOnNavbar(visible) {
    // check login/logout
    if (visible) {   // logged_in cookie exist, show logout
        $('#navbar_login').removeClass('hidden');
        $('#navbar_logout').addClass('hidden');

    } else {
        $('#navbar_login').addClass('hidden');
        $('#navbar_logout').removeClass('hidden');
    }
}


// call server login
function doLogin2() {
    console.log($("#navbar_loginform").serializeArray());

    $.post('/jcrest.pl/login', {username: $("#navbar_username").val(), password: $("#navbar_password").val()},
        function (returnedData) {
            console.log(returnedData);
        }).fail(function () {
        console.log("login fail");
    });

}

// call server login
function doLogin() {
    console.log($("#navbar_loginform").serializeArray());

    $.ajax({
        url: jirarest_login, // global variable for login url
        type: "post",
        data: {
            username: $("#navbar_username").val(),
            password: $("#navbar_password").val()
        },
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            showLoginOnNavbar(false);
        },
        error: function (jqXhr, textStatus, errorThrown) {
            showLoginOnNavbar(true);
        }
    });
}

// calll server logout
function doLogout() {
    console.log("========== doLogout...");
    $.ajax({
        url: '/jcrest.pl/logout',
        type: 'get',
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            showLoginOnNavbar(true);
            console.log('logout success');

        },
        error: function (jqXhr, textStatus, errorThrown) {
            showLoginOnNavbar(false);
            console.log('logout fail');
        }
    });

}

// call server login
function doLogout2() {


    $.get('/jcrest.pl/logout',
        function (returnedData) {
            console.log(returnedData);
        }).fail(function () {
        console.log("logout fail");
    });

}