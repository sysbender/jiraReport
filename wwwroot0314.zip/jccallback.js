/**
 * Created by jmeng on 3/7/2017.
 */

function exportData() {
    alasql("SELECT * INTO CSV('worklog.csv') FROM ?", [worklogArray]);
}

//get issues of a filter
function getIssuesByFilter() {
    worklogArray = [];
    var filterUrl = $('select#filterSelect').val();
    console.log(filterUrl);
    restGetStartAt(filterUrl, filterCallback, 0, 100);
}


// process the json object list of a filter
function filterCallback(jsonData) {
    // console.log('================= length of issues in filter :' + jsonData.length );
    // pagination
    /*        var startAt = jsonData.startAt;
     var maxResults = jsonData.maxResults;
     var total = jsonData.total;*/


    console.log('maxResults = ' + jsonData.maxResults);
    console.log('issuesNumber = ' + jsonData.issues.length);
    // for each issue
    $.each(jsonData.issues, function (index, value) {
        var issueUrl = value.self;
        restGet(issueUrl, issueCallback);

    });
}


// get filters of current login user
function getFavoriteFilters() {
    //restGet('http://jira.presagis.com/rest/api/2/filter/favourite', favoriteFiltersCallback);
    restGet('http://jira.presagis.com/rest/api/2/filter/favourite', favoriteFiltersCallback);

}

// process the json object list of the favorite filters
function favoriteFiltersCallback(jsonData) {
    console.log('================= length of favoriteFilters :' + jsonData.length);
    $.each(jsonData, function (index, value) {
        // process each filter
        restGetStartAt(value.searchUrl, filterCallback, 0, 100);
        console.log(value.name);
        console.log(value.jql);
        console.log(value.searchUrl);
    });
}


// issue call back

function issueCallback(jsonData) {
    // get url
    var issueWorklogsUrl = jsonData.self + '/worklog';
    // get all worklogs for this issue
    restGet(issueWorklogsUrl, worklogCallback);

}

// worklog call back
function worklogCallback(jsonData) {
    console.log('worklog json data');
    console.log(jsonData);

    $.each(jsonData.worklogs, function (index, value) {
        console.log('value============');
        console.log(value);
        var updateAuthorName = value.updateAuthor.name;
        var started = value.started;
        var timeSpentSeconds = value.timeSpentSeconds;
        console.log('======worklog ' + index + ' :' + updateAuthorName + started + timeSpentSeconds);
        worklogArray.push({'updateAuthorName': updateAuthorName, 'updateAuthorName': parseInt(updateAuthorName)});
        console.log('length of worklogArray = ' + worklogArray.length);

    });
}


//------------------------------------------------------------------------------------------------------
//------------------------------------get worklog for selected filter------------------------------------


//get worklogs of a filter
function getWorklogsByFilter() {
    // clear worklogArray
    worklogArray = [];
    // get searchUrl for selected filter
    var filterUrl = $('select#filterSelect').val();
    // append : fields=worklog
    var newFilterUrl = filterUrl + '&fields=worklog';

    console.log('f=getWorklogsByFilter, filterUrl=' + newFilterUrl);
    restGetStartAt(newFilterUrl, getWorklogsByFilterCallback, 0, jirarest_maxResults);
}


//startAt, maxResults
function getWorklogsByFilterCallback(jsonData, restUrl) {

    console.log('maxResults = ' + jsonData.maxResults);
    console.log('issuesNumber = ' + jsonData.issues.length);


    // for each issue
    $.each(jsonData.issues, function (index, value) {
        console.log("================issue ===========================");
        console.log(value);
        var issue = value;
        var issueUrl = issue.self;
        var worklogs = issue.fields.worklog.worklogs;
        $.each(worklogs, function (index, value) {
            var worklog = value;
            console.log('value============');
            console.log(value);
            var updateAuthorName = worklog.updateAuthor.name;
            var started = worklog.started;
            var timeSpentSeconds = worklog.timeSpentSeconds;
            var id = worklog.id;
            console.log('======worklog ' + index + ' :' + updateAuthorName + started + timeSpentSeconds);
            worklogArray.push({
                'sUpdateAuthorName': updateAuthorName,
                'nTimeSpentSeconds': parseInt(timeSpentSeconds),
                'sId': id
            });
            console.log('---------------length of worklogArray = ' + worklogArray.length);
            console.log('*************length of promiseSet = ' + promiseSet.size);

        });  // end worklog

        // restGet(issueUrl, issueCallback);

    }); // end issue

}


// return an array of worklog, new version used for avoid global variable
//startAt, maxResults
function retrieveWorklogsByFilterCallback(jsonData, restUrl, arrayWorklog) {

    console.log('maxResults = ' + jsonData.maxResults);
    console.log('issuesNumber = ' + jsonData.issues.length);



    // for each issue
    $.each(jsonData.issues, function (index, value) {
        console.log("================issue ===========================");
        console.log(value);
        var issue = value;
        console.log('retrieve issue =======================' );
        console.log(issue);
        var issueUrl = issue.self;
        // for each issue
        var issueType = issue.fields.issuetype.name; // get issueType
        var projectKey = issue.fields.project.key;  // get projectKey
        var worklogs = issue.fields.worklog.worklogs;
        console.log('worklogs length');
        $.each(worklogs, function (index, value) {
            var worklog = value;
            console.log(value);
            var updateAuthorName = worklog.updateAuthor.name;
            var created = new Date(worklog.created);
            var updated = new Date(worklog.updated);
            var started = new Date(worklog.started);
            var timeSpentSeconds = worklog.timeSpentSeconds;
            var id = worklog.id;
            console.log('======worklog ' + index + ' :' + updateAuthorName + started );
            console.log(arrayWorklog);
            arrayWorklog.push(
                {
                    'projectKey':projectKey,
                    'issueType':issueType,
                    'updateAuthorName': updateAuthorName,
                    'created':created,
                    'updated':updated,
                    'started':started,
                    'timeSpentSeconds': parseInt(timeSpentSeconds)
                });
        });  // end worklog
        console.log('---------------retrived worklogs in arrayWorklog = ' + worklogArray.length);
    }); // end issue

}


//------------------------------------------------------------------------------------------------------
//----------------------------------get filters for select------------------------------------
// call on click butten

function doFillFilterSelect() {


    restGet(jirarest_api + '/filter/favourite', fillFilterSelect);
}


// process the json object list of the favorite filters
function fillFilterSelect(jsonData) {
    console.log('================= length of favoriteFilters :' + jsonData.length);
    $('#filterSelect').empty();
    $.each(jsonData, function (index, value) {
        // remove all option

        // addprocess each filter, add filter to select
        $('#filterSelect').append(new Option(value.name, value.searchUrl, false, false));
        console.log(value.name);
        console.log(value.jql);
        console.log(value.searchUrl);
    });
}

