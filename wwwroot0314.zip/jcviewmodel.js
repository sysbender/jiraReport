/**
 * Created by jason on 3/12/2017.
 */
// class to represent worklog

var Worklog = function (wLabel, wProjectKey, wIssueType, wUpdateAuthorName, wCreated,
                        wUpdated, wStarted, wTimeSpentSeconds) {

    this.label = wLabel;
    this.projectKey = wProjectKey;
    this.issueType = wIssueType;
    this.updateAuthorName = wUpdateAuthorName;
    this.created = wCreatedDate;
    this.updated = wUpdatedDate;
    this.started = wStartedDate;
    this.timeSpentSeconds = wTimeSpentSeconds;

}

// Constructor for an object with two properties
var Filter = function (fId, fName, fJql, fSearchUrl) {
    this.id = fId;
    this.name = fName;
    this.jql = fJql;
    this.searchUrl = fSearchUrl;
};


function Query(label, initFilter) {
    var self = this;
    // data
    self.label = label;
    self.filter = ko.observable(initFilter);
    self.worklogs = [];
    self.issueCount = ko.computed(function () {
        // get issue count from filter
    });
    self.worklogCount = function () {
        window.console.log(self.worklogs);
    };
    // retrieve worklog and put them ini self.worklogs
    self.retrieveWorklogs = function () {
        self.worklogs = [];
        var url = self.filter().searchUrl + jirarest_suffix;
        restRetrieveStartAt(url, retrieveWorklogsByFilterCallback, 0, jirarest_maxResults, self.worklogs);
    };

}

function TransformerField(initIndex, initReturnType, initLabel) {
    var self = this;
    self.rolenew = ko.observable('none');
    self.name = initLabel;
    self.index = initIndex;
    self.role = ko.observable('none'); // key , column, none
    self.transformer = ko.observable();
    self.returnType = ko.observable(initReturnType);
    self.label = ko.observable(initLabel);
    //self.columnId =  ko.observable();
    self.avalableRoles = ['key', 'column'];
    self.avalableTransformers = ko.observableArray(['month', 'count', 'avg', 'sum', 'min', 'max']);
    self.avalableReturnTypes = ['string', 'number', 'boolean', 'date'];

    /*ko.computed(function() {
     return self.name;
     });*/

    self.toJson = ko.computed(function () {
        var fieldJson = "";
        if (self.role) {
            fieldJson += "column: " + self.index;
            if (self.role == 'key') {
                fieldJson += ", modifier: " + self.transformer;
            }
            if (self.role == 'column') {
                fieldJson += ", aggregation: " + self.transformer;
            }
            if (self.returnType) {
                fieldJson += ",type: " + self.type;
            }
            fieldJson += "}";
        }
        return fieldJson;
    }, self);


}

function JCViewModel() {
    var self = this;

    // data for filter
    self.selectedFilter = ko.observable();
    self.availableFilters = ko.observableArray([]);
    // method for fitler
    self.addFilter = function (filter) {
        self.availableFilters.push(filter);
        window.console.log(self.availableFilters);
    }
    self.removeFilter = function () {
        self.availableFilters.pop();
        window.console.log(self.availableFilters);
    }
    self.clearFilter = function () {
        for (var i = 0; i < self.availableFilters.length; i++) {
            self.availableFilters.pop();
        }
        window.console.log(self.availableFilters);
    }
    self.testAddFilter = function () {
        self.availableFilters.push(new Filter('1', 'myfilter', 'project=sp', 'http-jira'));
        console.log(self.availableFilters);
    }


    // queries
    self.queries = ko.observableArray();
    // methods
    self.addQuery = function () {   // ?? where get this filter
        self.queries.push(new Query("mylabel", self.selectedFilter()));
        window.console.log(self.selectedFilter().name);
    };
    self.removeQuery = function (query) {
        self.queries.pop(query);
    };


    //
    self.dataTable = new google.visualization.DataTable();
    self.transformedDataTable;
    self.worklogToTableData = function () {
        var data = [];
        // for each query
        for (var i = 0; i < self.queries().length; i++) {
            data.push();
            // for each worklog array
            for (var j = 0; j < self.queries()[i].worklogs.length; j++) {
                // add label attribute to worklog obj
                var currentWorklog = self.queries()[i].worklogs[j];
                currentWorklog['label'] = self.queries()[i].label;
                data.push(currentWorklog);
            }
        }
        return data;
    };
    // draw table for queries
    self.drawOriginalDataTable = function () {
        window.console.log("start draw original table");
        self.dataTable = dataToDataTable(self.worklogToTableData());
        drawTable(self.worklogToTableData(), 'div_originalDataTable');

    };

    self.drawTransformedDataTable = function () {
    window.console.log(" +++++++++++++++++++++start draw transformed table");
        /*            window.console.log('-----------------------keys');
        window.console.log(self.transformersToJson('key'));
        window.console.log('------------------columns');
        window.console.log(self.transformersToJson('column'));*/
         //var keys = JSON.parse(self.transformersToJson('key'));
        //var keys = [{column : 0}];
         //var columns = JSON.parse(self.transformersToJson('column'));
/*        var columns = [{
            'column': 6,
            'aggregation': google.visualization.data.sum,
            'type': 'number'
        }];*/
        var keys = self.transformersToObj('key');
        var columns = self.transformersToObj('column');
        window.console.log(keys);
        window.console.log(columns);



        self.transformedDataTable = google.visualization.data.group(self.dataTable,keys,columns);
        window.console.log(self.transformedDataTable);
        transformAndDrawTable(self.worklogToTableData(), keys,columns, 'div_transformedDataTable');
    };
    //data transform
    self.transformerFields = ko.observableArray([]);
    self.initTransformerFields = function () {
        for (var i = 0; i < dataFields.length; i++) {
            self.transformerFields().push(new TransformerField(i, dataFields[i].type, dataFields[i].header));
        }
        /*            window.console.log(" columns numbers  = "  + self.dataTable.getNumberOfColumns());
         for(var i=0; i<self.dataTable.getNumberOfColumns(); i++){
         self.transformerFields().push(
         new TransformerField(i,
         self.dataTable.getColumnLabel(i),
         self.dataTable.getColumnType(i),
         self.dataTable.getColumnLabel(i)));
         }*/


    };

    // load chart editor
    self.clickChartEditor =function () {
        loadEditor(self.transformedDataTable );
    };

    // get modifier : selectedRole = 'key'
    // get aggregation ='column'


    self.transformersToObj = function (selectedRole) {
        var json = "[";
        var arr=[];
        for (var i = 0; i < self.transformerFields().length; i++) {
            var role = self.transformerFields()[i].role();
            //window.console.log(i + '===========================' + selectedRole);
            //window.console.log(role);
            var fieldJson = "";


            if (typeof role !== 'undefined' && role !== null && role == selectedRole) {
                if (json.length > 2) {
                    fieldJson += " , {";
                } else {
                    fieldJson += "{";
                }
                var obj= new Object();
                //window.console.log('valid line');
                obj.column = self.transformerFields()[i].index;
                fieldJson += '"column": ' + self.transformerFields()[i].index;
                var transformer = self.transformerFields()[i].transformer();
                if (typeof transformer !== 'undefined' && transformer !== null) {
                    if (role == 'key') {
                        fieldJson += ', "modifier": "' + self.transformerFields()[i].transformer()+'"';
                        //obj.modifier=self.transformerFields()[i].transformer();
                        obj.modifier = window["google"]["visualization"]["data"][self.transformerFields()[i].transformer()];
                    }
                    if (role == 'column') {
                        fieldJson += ', "aggregation": ' + "'google.visualization.data." + self.transformerFields()[i].transformer()+"'";
                        obj.aggregation= window["google"]["visualization"]["data"][self.transformerFields()[i].transformer()];
                        //"google.visualization.data."+self.transformerFields()[i].transformer();
                    }
                    if (self.transformerFields()[i].returnType) {
                        fieldJson += ',"type": "' + self.transformerFields()[i].returnType() + '"';
                        obj.type=self.transformerFields()[i].returnType();
                    }

                }

                fieldJson += "}";
                arr.push(obj);

            }
            json += fieldJson;

        }
        json += ']'
        //window.console.log(json);
        //window.console.log("end");
        return arr;
    };
    self.sql = ko.observable("");


    // load favorite filters
    self.loadFilters = function () {
        self.clearFilter();
        restGet(jirarest_api + "/filter/favourite", function (jsonData, avaliableFitlers) {
            $.each(jsonData, function (index, value) {
                self.addFilter(new Filter(value.id, value.name, value.jql, value.searchUrl));
                var filter = {
                    filterId: value.id,
                    filterName: value.name,
                    jql: value.jql,
                    searchUrl: value.searchUrl
                };
                console.log(filter);

                // refresh bootstrap select options
                //bsFilter.append('<option value="'+value.id+'">'+value.name+'</option>');
            });
            //bsFilter.selectpicker("refresh");
            console.log("all filters ========================");
            console.log(self.availableFilters);
        })
    }

}

