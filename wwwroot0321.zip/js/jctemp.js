/**
 * Created by jmeng on 3/21/2017.
 */


var vmQuery =function () {
    //public
    self.queries;
    self.datatable;
    //private

};

var vmTransform = function () {
    //public
    self.transforms;
    self.transformedDataTable;
};

var vmEditor =function () {
    // public
    self.chartOptions;
    self.saveDefinition;
    self.loadDefinition;
    self.loadedDefinition;
};