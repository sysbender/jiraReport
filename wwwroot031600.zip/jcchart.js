/**
 * Created by jmeng on 3/15/2017.
 */
//-----------------------------------------loadEditor
//-----------------------------------------loadEditor
<!-- chartEditor -->

//google.charts.setOnLoadCallback(loadEditor);
/*var chartEditor = null;
var wrapperOptionsJson = null;
function loadEditor(dataTable) {
    var wrapper = new google.visualization.ChartWrapper();
    wrapper.setDataTable(dataTable);
    // create chartEditor
    chartEditor = new google.visualization.ChartEditor();
    // register to listen for OK
    google.visualization.events.addListener(chartEditor, 'ok', redrawChart);
    // open the chartEditor as an embedded dialog box on the page
    chartEditor.openDialog(wrapper, {});
}


function redrawChart() {
    var wrapper = chartEditor.getChartWrapper();
    var json = chartEditor.getChartWrapper().toJSON();
    wrapperOptionsJson =json;
    chartEditor.getChartWrapper().draw(document.getElementById('div_previewChart'));
}*/

/**
 * get Json from customized chart wrapper
 * @returns {string}
 */
function chartWrapperToJson(){
    //var wrapper = chartEditor.getChartWrapper();

    var wrapperJson =  chartEditor.getChartWrapper().toJSON();
    console.log('==========wrapper json ');
    console.log(wrapperJson);
    var wrapperObj = JSON.parse(wrapperJson);
    console.log('==========wrapper Object ');
    console.log(wrapperObj);
    /**
     * chartWrapper
     * getChartType
     * getChartName
     * getOptions
     */

    return wrapperJson;
}


var jcchart;
jcchart = {
    id: 'div_previewChart',
    type: 'PieChart',
    datatable: null,
    wrapper : null,
    editor: null,
    // new wrapper
    init: function () {
        jcchart.wrapper = new google.visualization.ChartWrapper();
        jcchart.wrapper.setContainerId(jcchart.id);
        jcchart.wrapper.setChartType(jcchart.type);
       // jcchart.redraw();
    },
    load: function (dt) {   //new wrapper
        jcchart.datatable = dt;
        jcchart.wrapper = new google.visualization.ChartWrapper(jcchart.datatable);
        jcchart.wrapper.setContainerId(jcchart.id);
        jcchart.wrapper.setChartType(jcchart.type);

        jcchart.wrapper.draw();
    },

    redraw: function () {
        //jcchart.wrapper.setDataTable(dt);
        jcchart.wrapper.setDataTable(jcchart.datatable);
        jcchart.wrapper.draw();
    },
    edit: function () {
        if(jcchart.editor== null || typeof jcchart.editor == undefined){
            jcchart.editor = new google.visualization.ChartEditor();
            google.visualization.events.addListener(jcchart.editor, 'ok', function () {
                jcchart.wrapper = jcchart.editor.getChartWrapper();
                jcchart.redraw();
            });
        }
        jcchart.editor.openDialog(jcchart.wrapper, {});
        return false;
    },
    toJson : function () {
        var json  =jcchart.wrapper.toJson();
        console.log(json);
        return json;
    }


};



