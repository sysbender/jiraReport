/**
 * Created by jason on 3/12/2017.
 */
// class to represent worklog

var Worklog = function (wLabel, wProjectKey, wIssueType, wUpdateAuthorName, wCreated,
                        wUpdated, wStarted, wTimeSpentSeconds) {

    this.label = wLabel;
    this.projectKey = wProjectKey;
    this.issueType = wIssueType;
    this.updateAuthorName = wUpdateAuthorName;
    this.created = wCreatedDate;
    this.updated = wUpdatedDate;
    this.started = wStartedDate;
    this.timeSpentSeconds = wTimeSpentSeconds;

}

// Constructor for an object with two properties
var Filter = function (fId, fName, fJql, fSearchUrl) {
    this.id = fId;
    this.name = fName;
    this.jql = fJql;
    this.searchUrl = fSearchUrl;
};


function Query(label, initFilter) {
    var self = this;
    // data
    self.label = label;
    self.filter = ko.observable(initFilter);
    self.worklogs = [];
    self.issueCount = ko.computed(function () {
        // get issue count from filter
    });
    self.worklogCount = function () {
        window.console.log(self.worklogs);
    };
    // retrieve worklog and put them in self.worklogs
    self.retrieveWorklogs = function () {
        self.worklogs = [];
        var url = self.filter().searchUrl + jirarest_suffix;
        restRetrieveStartAt(url, retrieveWorklogsByFilterCallback, 0, jirarest_maxResults, self.worklogs);
    };

}

function TransformerField(initIndex, initReturnType, initLabel) {
    var self = this;
    self.rolenew = ko.observable('none');
    self.name = initLabel;
    self.index = initIndex;
    self.role = ko.observable('none'); // key , column, none
    self.transformer = ko.observable();
    self.returnType = ko.observable(initReturnType);
    self.label = ko.observable(initLabel);
    //self.columnId =  ko.observable();
    self.availableRoles = ['key', 'column'];
    self.availableTransformers = ko.observableArray(['toMonth','toWeek','toYear','toQuarter','toYYQ', 'count', 'avg', 'sum', 'min', 'max']);
    self.availableReturnTypes = ['string', 'number', 'boolean', 'date'];

    /*ko.computed(function() {
     return self.name;
     });*/


}

function JCViewModel() {
    var self = this;

    // data for filter
    self.selectedFilter = ko.observable();
    self.availableFilters = ko.observableArray([]);
    // method for fitler
    self.addFilter = function (filter) {
        self.availableFilters.push(filter);
        window.console.log(self.availableFilters);
    }
    self.removeFilter = function () {
        self.availableFilters.pop();
        window.console.log(self.availableFilters);
    }
    self.clearFilter = function () {
        for (var i = 0; i < self.availableFilters.length; i++) {
            self.availableFilters.pop();
        }
        window.console.log(self.availableFilters);
    }
    self.testAddFilter = function () {
        self.availableFilters.push(new Filter('1', 'myfilter', 'project=sp', 'http-jira'));
        console.log(self.availableFilters);
    }


    // queries
    self.queries = ko.observableArray();
    // methods
    self.addQuery = function () {   // ?? where get this filter
        self.queries.push(new Query("mylabel", self.selectedFilter()));
        window.console.log(self.selectedFilter().name);
    };
    self.removeQuery = function (query) {
        self.queries.remove(query);
    };
    self.retrieveAllWorklogs =function () {
        console.log(" === retrieve all worklogs =" +self.queries().length);
        for(var i=0; i<self.queries().length; i++){
            console.log(self.queries()[i]);

            (self.queries()[i]).retrieveWorklogs();
        }
    };


    //
    self.dataTable = ko.observable(new google.visualization.DataTable());
    self.transformedDataTable = ko.observable(new google.visualization.DataTable());
    self.dataTableCsvUri =  ko.computed( function () {
        var csv =google.visualization.dataTableToCsv(self.dataTable());
        return 'data:application/csv;charset=utf-8,' + encodeURIComponent(csv);
    }, this);
    self.transformedDataTableCsvUri = ko.computed(function () {
        var csv =google.visualization.dataTableToCsv(self.transformedDataTable());
        return 'data:application/csv;charset=utf-8,' + encodeURIComponent(csv);
    });

    self.worklogToTableData = function () {
        var data = [];
        // for each query
        for (var i = 0; i < self.queries().length; i++) {
            data.push();
            // for each worklog array
            for (var j = 0; j < self.queries()[i].worklogs.length; j++) {
                // add label attribute to worklog obj
                var currentWorklog = self.queries()[i].worklogs[j];
                currentWorklog['label'] = self.queries()[i].label;
                data.push(currentWorklog);
            }
        }
        return data;
    };
    // draw table for queries
    self.drawOriginalDataTable = function () {
        window.console.log("start draw original table");
        self.dataTable(dataToDataTable(self.worklogToTableData()));
        drawTable(self.worklogToTableData(), 'div_originalDataTable');

    };

    self.drawTransformedDataTable = function () {
    window.console.log(" +++++++++++++++++++++start draw transformed table");
        /*
        //var keys = [{column : 0}];
 /*        var columns = [{
            'column': 6,
            'aggregation': google.visualization.data.sum,
            'type': 'number'
        }];*/
        var keys = self.transformersToObj('key');
        var columns = self.transformersToObj('column');
        window.console.log(keys);
        window.console.log(columns);



        self.transformedDataTable (google.visualization.data.group(self.dataTable(),keys,columns));
        window.console.log(self.transformedDataTable);
        transformAndDrawTable(self.worklogToTableData(), keys,columns, 'div_transformedDataTable');

    };
    //data transform

    self.selectedField = ko.observable();
    self.availableFields = ko.observableArray(dataFields);

    self.transformerFields = ko.observableArray(

    );
    self.addField = function () {
        window.console.log("=========add field");
        self.transformerFields.push(new TransformerField( self.selectedField().index, self.selectedField().type, self.selectedField().header));
    };
    self.removeField = function (field) {
        self.transformerFields.remove(field);
    };

    self.initTransformerFields = function () {
        for (var i = 0; i < dataFields.length; i++) {
            self.transformerFields().push(new TransformerField(i, dataFields[i].type, dataFields[i].header));
        }
        /*            window.console.log(" columns numbers  = "  + self.dataTable.getNumberOfColumns());
         for(var i=0; i<self.dataTable.getNumberOfColumns(); i++){
         self.transformerFields().push(
         new TransformerField(i,
         self.dataTable.getColumnLabel(i),
         self.dataTable.getColumnType(i),
         self.dataTable.getColumnLabel(i)));
         }*/


    };

/*    // load chart editor
    self.clickChartEditor =function () {
        loadEditor(self.transformedDataTable );
    };*/

    // get modifier : selectedRole = 'key'
    // get aggregation ='column'
    self.transformersToObj = function (selectedRole) {
        var arr=[];
        for (var i = 0; i < self.transformerFields().length; i++) {
            var role = self.transformerFields()[i].role();
            if (typeof role !== 'undefined' && role !== null && role == selectedRole) {
                var obj= new Object();
                obj.column = self.transformerFields()[i].index;
                var transformer = self.transformerFields()[i].transformer();
                if (typeof transformer !== 'undefined' && transformer !== null) {
                    if (role == 'key') {
                        //obj.modifier = window["google"]["visualization"]["data"][self.transformerFields()[i].transformer()];
                        obj.modifier = window[self.transformerFields()[i].transformer()];
                    }
                    if (role == 'column') {
                        obj.aggregation= window["google"]["visualization"]["data"][self.transformerFields()[i].transformer()];
                    }
                    if (self.transformerFields()[i].returnType) {
                        obj.type=self.transformerFields()[i].returnType();
                    }
                    if (typeof self.transformerFields()[i].label  !== 'undefined' && self.transformerFields()[i].label  !== null && self.transformerFields()[i].label != self.transformerFields()[i].name ) {
                        obj.label=self.transformerFields()[i].label();
                    }
                }
                arr.push(obj);
            }
        }
        return arr;
    };


    // not using
    self.sql = ko.observable("");


    // load favorite filters
    self.loadFilters = function () {
        self.clearFilter();
        restGet(jirarest_api + "/filter/favourite", function (jsonData, avaliableFitlers) {
            $.each(jsonData, function (index, value) {
                self.addFilter(new Filter(value.id, value.name, value.jql, value.searchUrl));
                var filter = {
                    filterId: value.id,
                    filterName: value.name,
                    jql: value.jql,
                    searchUrl: value.searchUrl
                };
                console.log(filter);

                // refresh bootstrap select options
                //bsFilter.append('<option value="'+value.id+'">'+value.name+'</option>');
            });
            //bsFilter.selectpicker("refresh");
            console.log("all filters ========================");
            console.log(self.availableFilters);
        })
    }


    /**
     * chart editor
     */

    self.chartEditor = null;
    var wrapperOptionsJson = null;
    self.loadEditor = function () {
        var wrapper = new google.visualization.ChartWrapper();
        wrapper.setDataTable(self.transformedDataTable());
        // create chartEditor
        self.chartEditor = new google.visualization.ChartEditor();
        // register to listen for OK
        google.visualization.events.addListener(self.chartEditor, 'ok', function () {
            // get a updated wrapper
            var wrapper = self.chartEditor.getChartWrapper();
            self.wrapperOptionsJson = self.chartEditor.getChartWrapper().toJSON();
            self.chartEditor.getChartWrapper().draw(document.getElementById('div_previewChart'));
            self.createJcdefinition();
        });
        // open the chartEditor as an embedded dialog box on the page
        self.chartEditor.openDialog(wrapper, {});
    }


/*
    function redrawChart() {
        // get a updated wrapper
        var wrapper = self.chartEditor.getChartWrapper();
        self.wrapperOptionsJson = self.chartEditor.getChartWrapper().toJSON();
        self.chartEditor.getChartWrapper().draw(document.getElementById('div_previewChart'));
    }
*/

    /**
     * convert to json and save jcchart
     */
   self.createJcdefinition = function () {
       var jcdefinition = new Object();
       jcdefinition.queries = [];
       for(var i=0; i<self.queries().length; i++){
           jcdefinition.queries.push([{label: self.queries()[i].label, filter:  self.queries()[i].filter()}]);
       }
       jcdefinition.transformers ={};
       jcdefinition.transformers.keys = self.transformersToObj('key');
       jcdefinition.transformers.columns = self.transformersToObj('column');
       jcdefinition.wrapper={};
       var opt = JSON.parse(self.wrapperOptionsJson);
       jcdefinition.wrapper.options= opt.options;
       jcdefinition.wrapper.chartType = opt.chartType;
/*       jcdefinition.wrapper.chartType=  chartEditor.getChartWrapper().getChartType();
       jcdefinition.wrapper.chartName =  chartEditor.getChartWrapper().getChartName();
       jcdefinition.wrapper.options =  chartEditor.getChartWrapper().getOptions();*/
       console.log("jcdefinition=======");
       console.log(jcdefinition);
       console.log("jcdefinition=======");
       console.log(JSON.stringify(jcdefinition));
       // write a file
       var obj = {a: 123, b: "4 5 6"};
       var data = "text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(jcdefinition));

       var a = document.createElement('a');
       a.href = 'data:' + data;
       a.download = 'jira-chart-sample.json';
       a.innerHTML = 'save Jira Chart';

       var container = document.getElementById('div_saveJiraChart');
       container.appendChild(a);

       //chartWrapperToJson();
       return jcdefinition;

   };


}



