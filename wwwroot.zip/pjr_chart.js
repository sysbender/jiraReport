/**
 * Created by jmeng on 3/6/2017.
 */
<script type="text/javascript">

    // google.charts.setOnLoadCallback(drawTable);

    google.charts.load('current', {'packages': ['table']});
var data ; //new google.visualization.DataTable();
var rows;
function drawTable() {
    if(worklogArray ==undefined || worklogArray == null ) return false;
    console.log('==============draw table called');
    var table_options = {page: 'enable', pageSize: 10, showRowNumber: true, width: '50%', height: '50%'};

    data = new google.visualization.DataTable();
    $.each(worklogArray[0], function(key , element){

        var columnType = key.substring(0,1);
        switch(columnType){
            case 's':
                data.addColumn('string', key);
                break;
            case 'n':
                data.addColumn('number', key);
                break;
            case 'b':
                data.addColumn('boolean', key);
                break;
            case 'd':
                data.addColumn('date', key);
                break;
            case 't':
                data.addColumn('timeofday', key);
                break;
            default:
                data.addColumn('string', key);

        }

    });

    // get data for google table
    rows=[];
    for(var rowIndex =0; rowIndex< worklogArray.length; rowIndex++){

        var row = [];
        for( var columnIndex=0; columnIndex< data.getNumberOfColumns(); columnIndex++){
            var columnLabel = data.getColumnLabel(columnIndex);
            row.push(worklogArray[rowIndex][columnLabel]);
        }
        rows.push(row);

    }
    console.log(rows);
    data.addRows(rows);



    //$.each( worklogArray, function (key, value) {


    //data.addColumn('string', 'Name');

    /*            data.addRows([
     ['Mike',  {v: 10000, f: '$10,000'}, true],
     ['Jim',   {v:8000,   f: '$8,000'},  false],
     ['Alice', {v: 12500, f: '$12,500'}, true],
     ['Bob',   {v: 7000,  f: '$7,000'},  true]
     ]);*/
    //data.addRows(worklogArray);

    var table = new google.visualization.Table(document.getElementById('table_div'));

    table.draw(data, table_options);


    // Set chart options
    var options = {'title':'jira report @ Presagis',
        'width':550,
        'height':400};
    //Instantiate and draw the chart.
    var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
    chart.draw(data, options);

}
</script>
