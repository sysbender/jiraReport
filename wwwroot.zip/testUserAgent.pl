#!/usr/bin/perl
use strict;
use warnings FATAL => 'all';

use Mojo::Base -strict;
use Mojo::UserAgent;
use Data::Dumper;
my $ua = Mojo::UserAgent->new;

# cookie auth
my $tx1 = $ua->post(
    'https://jeanreve.atlassian.net/rest/auth/1/session' => {Accept => '*/*'} => json => {username => 'Jason.Meng', password => 'Jira3694867'});
print $tx1->result->body;
print "===============\n";
print Dumper($tx1->result->cookies);



#my $tx = $ua->get('https://jeanreve.atlassian.net/rest/api/2/myself');
# OR if your username has an @
my $url = Mojo::URL->new('https://jeanreve.atlassian.net/rest/auth/1/session');
my $tx = $ua->get($url);

print $tx->res->body;

