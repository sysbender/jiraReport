/**
 * Created by jmeng on 3/7/2017.
 */


// array for all worklogs
var worklogArray = [];
var jirarest_proxy = 'jcrest.pl/getjira?url=';
var jirarest_api = 'http://jira.presagis.com/rest/api/2';
var jirarest_maxResults = 100;  // how many issues for each query
// set for ajax promise
var promiseSet = new Set();


// fill select choices
$(document).ready(function () {
    console.log('ready  ddd');
    // restGet('http://jira.presagis.com/rest/api/2/filter/favourite', fillFilterSelect);
    $('#ajax-process-bar').height(5);
    $('#ajax-process-bar').progressbar({ value: 0 });


});