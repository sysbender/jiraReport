/**
 * Created by jmeng on 3/6/2017.
 */



function promiseGetIssuesByFilter() {
    worklogArray.length = 0;
    console.log(' initworklogArray size: ' + worklogArray.length);
    var filterUrl = $('select#filterSelect').val();
    console.log(filterUrl);
    promiseRestGetStartAt(filterUrl, 0, 100);
}


// promise call rest api recursively and get all issues from a filter
function promiseRestGetStartAt(restUrl, startAt, maxResults) {
    var newRestUrl = restUrl + '&startAt=' + startAt + '&maxResults=' + maxResults;
    console.log('==============restUrl = ' + restUrl);
    // get current page
    var promiseCurrent = promiseRestGet(newRestUrl);

    // success
    promiseCurrent.done(function (data) {
        // process the data from first page
        //jsonCallback(data);
        // for each issue
        $.each(data.issues, function (index, value) {
            var issueUrl = value.self;
            var promiseIssue = promiseRestGet(issueUrl);
            promiseSet.add(promiseIssue);
            // process an issue
            promiseIssue.done(function (data) {
                promiseSet.delete(promiseIssue);
                // get url
                var issueWorklogsUrl = data.self + '/worklog';
                // get all worklogs for this issue
                var promiseWorklog = promiseRestGet(issueWorklogsUrl);
                promiseSet.add(promiseWorklog);
                promiseWorklog.done(function (data) {
                    promiseSet.delete(promiseWorklog);
                    //, worklogCallback
                    $.each(data.worklogs, function (index, value) {
                        console.log('value============');
                        console.log(value);
                        var updateAuthorName = value.updateAuthor.name;
                        var started = value.started;
                        var timeSpentSeconds = value.timeSpentSeconds;
                        var id = value.id;
                        console.log('======worklog ' + index + ' :' + updateAuthorName + started + timeSpentSeconds);
                        worklogArray.push({'sUpdateAuthorName': updateAuthorName,  'nTimeSpentSeconds': parseInt(timeSpentSeconds), 'sId': id});
                        console.log('---------------length of worklogArray = ' + worklogArray.length);
                        console.log('*************length of promiseSet = ' + promiseSet.size);

                    });
                });
            });

        });
        // get the next page
        console.log(data);
        var nStartAt = parseInt(data.startAt);
        var nMaxResults = parseInt(data.maxResults);
        var nTotal = parseInt(data.total);
        var nNewStartAt = nStartAt + nMaxResults;
        // get the next page
        if (( nNewStartAt) < nTotal) {
            console.log('================== start recursively : new start= ' + nNewStartAt + ' total = ' + nTotal);
            promiseRestGetStartAt(restUrl, nNewStartAt, nMaxResults);
        }


    });

    //fail
    promiseCurrent.fail(function () {
        console.log('  fail to get : ' + newRestUrl);
    });

}


// promise rest get : return a promise
function promiseRestGet(restUrl) {

    return ajaxPromise = $.ajax({
        url: restUrl,
        type: "GET",
        dataType: 'json',
        contentType: 'application/json'


    });
}


// promise get all from filter
/*    function promiseGetIssuesByFilter() {
 var filterUrl = $('select#filterSelect').val();
 console.log(filterUrl);
 promiseRestGetStartAt(filterUrl,  0, 100);
 }*/
