use strict;
use warnings;
use URI::Split qw(uri_split uri_join);
use Mojolicious::Lite;
use Mojo::Base - strict;
use Mojo::UserAgent;
use Mojo::Util qw(secure_compare);
use JSON::PP;
use Data::Dumper;
use Storable;
# use JIRA::REST;



# App instructions
get '/' => qw(index);
# -------------------------------------------------------------------- #
# return time to client , for demo
any [ 'GET', 'POST' ] => '/getapi' => sub {
        # read config file
        my $config = plugin Config => { file => 'jcrest.conf' };
        my $jirarest_api = $config->{jirarest_api};
        my $json = JSON->new;
        my $json_text = $json->escape_slash(0)->encode({"jirarest_api" => $jirarest_api });
        #$self->render(json => {"error" => "fail to get" ,"session"=>$JIRA_JSESSIONID });


        shift->render(data => $json_text);
    };
# -------------------------------------------------------------------- #
#  1. get username/password,
#  2. try login to $jirerest_api.'/session'
#  3. save cookies to file
any [ 'GET', 'POST' ] => '/login' => sub {
        my $self = shift;

        # Grab the request parameters
        my $username = $self->param('username');
        my $password = $self->param('password');
        # get jira rest api from config file
        my $config = plugin Config => { file => 'jcrest.conf' };
        my $jirarest_api = $config->{jirarest_api};
        my $jirarest_logfile = $config->{jirarest_logfile};

        #
        my $auth_url = get_host($jirarest_api).'/rest/auth/1/session';

        # try login to jira rest
        # with cookie auth
        my $ua = Mojo::UserAgent->new;
        my $tx;
        eval {
            $tx = $ua->post($auth_url
                 => { Accept => '*/*' } => json =>
                { username => $username, password => $password });
        };
        # write log
        open(my $fh, '>>',  $jirarest_logfile);
        print $fh "login username="." $username \n";
        # login sucess
        if ($tx != undef && $tx->result->is_success && $tx->result->code == 200) {
            # store cookies
            # get file name for saving the cookies
            my $jirarest_cookies = $config->{jirarest_cookies}.'.'.$username;
            store $ua->cookie_jar, $jirarest_cookies;

            my $cookie;
            my $session;
          #$self->session(jirarest_api => $api);
            $self->session(jirarest_api => $jirarest_api);
            $self->session(jirarest_cookies => $jirarest_cookies);
            $self->session(jirarest_logfile => $jirarest_logfile);
            $self->session(logged_in => 1);
            $self->session(username => $username);
            #$self->session(password => $password);
            return $self->render(json => { "login result" => 'loged in success'}, status => 200);
            #return $self->render(data => $tx->result->body, status => 200);
        } else {
            return $self->render(json => { "login result" => 'log in fail', "auth_url" => $auth_url  }, status =>
                403);
        }
    };

# -------------------------------------------------------------------- #
# Authentication
under(sub {
    my $self = shift;
    # Have access
    if ($self->session('logged_in')) {
        return 1;
    }
    # Do not have access
    $self->render(json =>{ status => "error", data => { message => "You are not loggedin" } }, status =>
        403
    );

    return undef;
});

# -------------------------------------------------------------------- #
# get : get one absolute url, return json
any [ 'GET', 'POST' ] => '/getjira' => sub {
        my $self = shift;
        #---------custom cookies
        my $jirarest_api = $self->session('jirarest_api');
        my $jirarest_cookies = $self->session('jirarest_cookies');
        my $jirarest_logfile = $self->session('jirarest_logfile');
        # get url from parameter
        my $url = Mojo::URL->new($self->param('url'));
        #my $url = $self->stash('url');

        # restore cookies for jira
        my $ua = Mojo::UserAgent->new;
        $ua->cookie_jar(retrieve($jirarest_cookies));
        my $tx;
        eval {
            $tx = $ua->get($url);
        };
        # write log
        open(my $fh, '>>',  $jirarest_logfile);
        print $fh " $url \n";
        #print $fh $tx->result->body;
        #print $fh "\n";
        close $fh;

        if ($@) {
            $self->render(json =>  { status => "error", data => { message => " fail to get" , "url" =>$url} },, status =>
                404 );
        } else {
            #my $json = JSON->new;
            #$json->escape_slash([1]);
            #my $json_text = $json->escape_slash(0)->encode($tx->result->text);
            #$self->render(json => {"error" => "fail to get" ,"session"=>$JIRA_JSESSIONID });
            $self->render(data =>  $tx->result->body);
        }
    };

# -------------------------------------------------------------------- #
# Just a GET request
get '/status' => sub {
        my $self = shift;
        if ($self->session('logged_in')) {
            $self->render(json => { "status " => "logged in " });
        } else {
            $self->render(json => { "status " => "not logged in " });
        }

    };


# -------------------------------------------------------------------- #
any [ 'GET', 'POST' ] => '/logout' => sub {
        my $self = shift;

        if ($self->session('logged_in')) {
            # Expire the session (deleted upon next request)
            my $jirarest_cookies = $self->session('jirarest_cookies');
            unlink $jirarest_cookies;
            $self->session(expires => 1);

            $self->render(json => { "logout result" => " logged out sucessfully " });
        } else {
            $self->render(json => { "logout result" => " you didn't log in " });
        }

    };

# -------------------------------------------------------------------- #
# Required

app->start;
# ==================================================================== #
# -------------------------------------------------------------------- #
# get_path : remove http://xxx.com part from url path, this is required by JIRS::REST lib
# 'http://jira.presagis.com/rest/api/2/filter/favourite' to '/rest/api/2/filter/favourite''
# for JIRS::REST , not used any more
sub get_path{
    my $url = $_[0];
    my ($scheme, $auth, $path, $query, $frag) = uri_split($url);
    return uri_join(undef, undef, $path, $query, $frag);
}
# -------------------------------------------------------------------- #
# get host part - http://jira.presagis.com
sub get_host{
    my $url = $_[0];
    my ($scheme, $auth, $path, $query, $frag) = uri_split($url);
    return uri_join($scheme, $auth);
}


__DATA__

@@ index.html.ep

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
    * {
    margin: 5px;
    }
    </style>
</head>
<body>

<form action="/jcrest.pl/login" method="post">
username: <input type="text" name="username"/> <br>
password: <input type="password" name="password"/>
<br>
<input type="submit" value="login"/>
</form>
<br>
<form action="/jcrest.pl/getjira" method="post">
<input type="text" name="url" size="80"  value="http://jira.presagis.com/rest/api/2/filter/favourite"/>
<br>
<input type="submit" value="get"/>
</form>
method list:
<ul>
<li>getapi</li>
<li>login?username=aaa&password=bbb</li>
<li>logout</li>
<li>getjira?url=http://jira.presagis.com/rest/api/2/filter/favourite</li>
</ul>

</body>
</html>
