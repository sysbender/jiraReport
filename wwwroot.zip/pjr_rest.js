/**
 * Created by jmeng on 3/6/2017.
 */

// array for all worklogs
var worklogArray = [];


function exportData() {
    alasql("SELECT * INTO CSV('worklog.csv') FROM ?", [worklogArray]);
}

//get issues of a filter
function getIssuesByFilter() {
    worklogArray = [];
    var filterUrl = $('select#filterSelect').val();
    console.log(filterUrl);
    restGetStartAt(filterUrl, filterCallback, 0, 100);
}


// get filters of current login user
function getFavoriteFilters() {
    //restGet('http://jira.presagis.com/rest/api/2/filter/favourite', favoriteFiltersCallback);
    restGet('http://jira.presagis.com/rest/api/2/filter/favourite', favoriteFiltersCallback);

}

// process the json object list of the favorite filters
function favoriteFiltersCallback(jsonData) {
    console.log('================= length of favoriteFilters :' + jsonData.length);
    $.each(jsonData, function (index, value) {
        // process each filter
        restGetStartAt(value.searchUrl, filterCallback, 0, 100);
        console.log(value.name);
        console.log(value.jql);
        console.log(value.searchUrl);
    });
}

// process the json object list of a filter
function filterCallback(jsonData) {
    // console.log('================= length of issues in filter :' + jsonData.length );
    // pagination
    /*        var startAt = jsonData.startAt;
     var maxResults = jsonData.maxResults;
     var total = jsonData.total;*/


    console.log('maxResults = ' + jsonData.maxResults);
    console.log('issuesNumber = ' + jsonData.issues.length);
    // for each issue
    $.each(jsonData.issues, function (index, value) {
        var issueUrl = value.self;
        restGet(issueUrl, issueCallback);

    });
}

// issue call back

function issueCallback(jsonData) {
    // get url
    var issueWorklogsUrl = jsonData.self + '/worklog';
    // get all worklogs for this issue
    restGet(issueWorklogsUrl, worklogCallback);

}

// worklog call back
function worklogCallback(jsonData) {
    console.log('worklog json data');
    console.log(jsonData);

    $.each(jsonData.worklogs, function (index, value) {
        console.log('value============');
        console.log(value);
        var updateAuthorName = value.updateAuthor.name;
        var started = value.started;
        var timeSpentSeconds = value.timeSpentSeconds;
        console.log('======worklog ' + index + ' :' + updateAuthorName + started + timeSpentSeconds);
        worklogArray.push({'updateAuthorName': updateAuthorName, 'updateAuthorName': parseInt(updateAuthorName)});
        console.log('length of worklogArray = ' + worklogArray.length);

    });
}



// call rest api recursively and get all records
function restGetStartAt(restUrl, jsonCallback, startAt, maxResults) {
    var newRestUrl = restUrl + '&startAt=' + startAt + '&maxResults=' + maxResults;
    console.log('==============restUrl = ' + restUrl);
    $.ajax({
        url: newRestUrl,
        type: "GET",
        dataType: 'json',
        contentType: 'application/json',
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            var nStartAt = parseInt(data.startAt);
            var nMaxResults = parseInt(data.maxResults);
            var nTotal = parseInt(data.total);
            var nNewStartAt = nStartAt + nMaxResults;

            if (( nNewStartAt) < nTotal) {
                console.log('================== start recursively : new start= ' + nNewStartAt + ' total = ' + nTotal);
                restGetStartAt(restUrl, jsonCallback, nNewStartAt, nMaxResults);
            }
            jsonCallback(data);


        },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
            console.log('error =========');
        }

    });
}




//   jira rest api: http://jira.presagis.com/rest/api/2/filter/favourite
// get json data from restUrl, then use jsonCallback to process the data
function restGet(restUrl, jsonCallback) {
    $.ajax({
        url: restUrl,
        type: "GET",
        dataType: 'json',
        contentType: 'application/json',
        success: function (data, textStatus, jqXHR) {
            console.log(data);
            jsonCallback(data);
        },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
            console.log('error =========');
        }
    });
}

// getjson

// get an issue
$('#ajaxform').on('submit', function () {

    var that = $(this),
        url = that.attr('action'),
        type = that.attr('method'),
        data = {};
    var issue = $('#issue').val();
    url = url + issue;


    console.log(data);

    console.log(' pressed submit');

    $.ajax({
        url: url,
        type: "GET",
        dataType: 'json',
        contentType: 'application/json',
        success: function (response) {
            console.log(response);
        },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
            console.log('error =========');
        }

    });
    return false;
});


// fill select choices
$(document).ready(function () {
    console.log('ready');
    // restGet('http://jira.presagis.com/rest/api/2/filter/favourite', fillFilterSelect);
});


// process the json object list of the favorite filters
function fillFilterSelect(jsonData) {
    console.log('================= length of favoriteFilters :' + jsonData.length);
    $.each(jsonData, function (index, value) {
        // process each filter, add filter to select
        $('#filterSelect').append(new Option(value.name, value.searchUrl, false, false));
        console.log(value.name);
        console.log(value.jql);
        console.log(value.searchUrl);
    });
}


