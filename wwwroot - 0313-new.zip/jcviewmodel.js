/**
 * Created by jason on 3/12/2017.
 */
// class to represent worklog

var Worklog = function (wLabel, wProjectKey, wIssueType, wUpdateAuthorName, wCreated,
                        wUpdated, wStarted, wTimeSpentSeconds) {

    this.label = wLabel;
    this.projectKey = wProjectKey;
    this.issueType = wIssueType;
    this.updateAuthorName = wUpdateAuthorName;
    this.created = wCreatedDate;
    this.updated = wUpdatedDate;
    this.started = wStartedDate;
    this.timeSpentSeconds = wTimeSpentSeconds;

}

// Constructor for an object with two properties
var Filter = function (fId, fName, fJql, fSearchUrl) {
    this.id = fId;
    this.name = fName;
    this.jql = fJql;
    this.searchUrl = fSearchUrl;
};


function Query(label, initFilter) {
    var self = this;
    // data
    self.label = label;
    self.filter = ko.observable(initFilter);
    self.worklogs = [];
    self.issueCount = ko.computed(function () {
        // get issue count from filter
    });
    self.worklogCount = function () {
        window.console.log(self.worklogs);
    };
    // retrieve worklog and put them ini self.worklogs
    self.retrieveWorklogs =function () {
        self.worklogs = [];
        var url = self.filter().searchUrl+jirarest_suffix;
        restRetrieveStartAt(url, retrieveWorklogsByFilterCallback, 0, jirarest_maxResults, self.worklogs );
    };

}

function TransformerField( initIndex, initName, initReturnType, initLabel) {
    var self = this;
    self.name =initName;
    self.index =initIndex;
    self.role = ko.observable('none'); // key , column, none
    self.transformer = ko.observable();
    self.returnType = initReturnType;
    self.label = initLabel;
    self.id;
    self.avalableRoles = ['key','column','none'];
    self.avalableTransformers = ko.computed(function () {
        if(this.role == 'key'){ return ['','month']};
        if(this.role='column' ) {return ['', 'count', 'avg', 'sum', 'min', 'max']};
        return [];
    });
    self.avalableReturnTypes = ['string', 'number', 'boolean', 'date'];

}

function JCViewModel() {
    var self = this;



    // data for filter
    self.selectedFilter = ko.observable();
    self.availableFilters = ko.observableArray([]);
    // method for fitler
    self.addFilter = function (filter) {
        self.availableFilters.push(filter);
        window.console.log(self.availableFilters);
    }
    self.removeFilter = function () {
        self.availableFilters.pop();
        window.console.log(self.availableFilters);
    }
    self.clearFilter = function () {
        for (var i = 0; i < self.availableFilters.length; i++) {
            self.availableFilters.pop();
        }
        window.console.log(self.availableFilters);
    }
    self.testAddFilter = function () {
        self.availableFilters.push(new Filter('1', 'myfilter', 'project=sp', 'http-jira'));
        console.log(self.availableFilters);
    }



    // queries
    self.queries = ko.observableArray();
    // methods
    self.addQuery = function () {   // ?? where get this filter
        self.queries.push(new Query("mylabel", self.selectedFilter()));
        window.console.log(self.selectedFilter().name);
    };
    self.removeQuery = function (query) {
        self.queries.pop(query);
    };
    // draw table for queries
    self.drawOriginalDataTable = function () {
        var data = [] ;
        // for each query
        for(var i=0; i<self.queries().length; i++){
            data.push();
            // for each worklog array
            for(var j=0;j<self.queries()[i].worklogs.length;j++){
                // add label attribute to worklog obj
                var currentWorklog = self.queries()[i].worklogs[j];
                currentWorklog['label'] = self.queries()[i].label;
                data.push(currentWorklog);
            }
        }

        window.console.log(data);
        drawTable(data, 'div_originalDataTable');

    };

    //data transform
    self.transformerFields = [];
    self.initTransformerFields = function () {
        for(var i=0; i<dataFields.length; i++){
            self.transformerFields.push(new TransformerField(i, dataFields[i].name,  dataFields[i].type,  dataFields[i].header));
        }
    };

    self.sql = ko.observable("");
    self.drawTransformedDataTable = function () {
        
    };

    // load favorite filters
    self.loadFilters = function () {
        self.clearFilter();
        restGet(jirarest_api + "/filter/favourite", function (jsonData, avaliableFitlers) {
            $.each(jsonData, function (index, value) {
                self.addFilter(new Filter(value.id, value.name, value.jql, value.searchUrl));
                var filter = {
                    filterId: value.id,
                    filterName: value.name,
                    jql: value.jql,
                    searchUrl: value.searchUrl
                };
                console.log(filter);

                // refresh bootstrap select options
                //bsFilter.append('<option value="'+value.id+'">'+value.name+'</option>');
            });
            //bsFilter.selectpicker("refresh");
            console.log("all filters ========================");
            console.log(self.availableFilters);
        })
    }

}

