/**
 * Created by jmeng on 3/6/2017.
 */
// google.charts.setOnLoadCallback(drawTable);
google.charts.load('current', {'packages': ['table']});
var data; //new google.visualization.DataTable();
var rows;

// draw dataTable from data on elementId
function drawTable(data, elementId){
    var table_options = {page: 'enable', pageSize: 10, showRowNumber: true, width: '100%', height: '100%'};

    var table = new google.visualization.Table(document.getElementById(elementId));
    table.draw(dataToDataTable(data), table_options);
}

// convert data to rows
// {id:1, name:'test'} => [1,'test']
function dataToRows(data) {
    if (data == undefined || data == null || data.length == 0) return [];
    var rows = [];
    // convert data to rows for google table
    for (var rowIndex = 0; rowIndex < data.length; rowIndex++) {
        var row =$.map(data[rowIndex],  function (value) {
            return value;
        });

        rows.push(row);
    }
    console.log('rows=====================');
    console.log(rows);
    return rows;
}
// create  a new dataTable, add columns and rows from data, return this dataTable
function dataToDataTable(data) {
    if (data == undefined || data == null || data.length == 0) return null;
    var dataTable = new google.visualization.DataTable();
    $.each(data[0], function (key, element) {
        //var columnType = key.substring(0, 1);
        console.log('column header = '+ getFieldHeader(key));
        dataTable.addColumn( getFieldType(key), getFieldHeader(key)); //data.addColumn('number', 'Hours per Day');
    });

    dataTable.addRows(dataToRows(data));
    return dataTable;
}


// prepare data for google dataTable

function drawTableDeprecated(dataTable, arrayData, elementId) {
    if (data == undefined || data == null) return false;
    console.log('==============draw table called');
    // table options


    // dataTable = new google.visualization.DataTable();
    $.each(data[0], function (key, element) {
        //var columnType = key.substring(0, 1);
        dataTable.addColumn( getFieldType(key), getFieldHeader(key)); //data.addColumn('number', 'Hours per Day');
    });

    // convert data to rows for google table
    rows = [];
    for (var rowIndex = 0; rowIndex < data.length; rowIndex++) {

        var row = [];
        for (var columnIndex = 0; columnIndex < dataTable.getNumberOfColumns(); columnIndex++) {
            //var columnLabel = dataTable.getColumnLabel(columnIndex);
            row.push(data[rowIndex][columnIndex]);
        }
        rows.push(row);
    }
    console.log(rows);
    dataTable.addRows(rows);


    //$.each( data, function (key, value) {
    //data.addColumn('string', 'Name');
    /*            data.addRows([
     ['Mike',  {v: 10000, f: '$10,000'}, true],
     ['Jim',   {v:8000,   f: '$8,000'},  false],
     ['Alice', {v: 12500, f: '$12,500'}, true],
     ['Bob',   {v: 7000,  f: '$7,000'},  true]
     ]);*/
    //data.addRows(data);




    // Set chart options
/*    var options = {
     'title': 'jira report @ Presagis',
     'width': 550,
     'height': 400
     };*/
    //Instantiate and draw the chart. ( not draw it hear , instead using chartEditor)
    //var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
    //chart.draw(data, options);

}

